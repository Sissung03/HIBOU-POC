from app.compute_confidence import FCSV, compute_confidence_state, geometric_aggregation
from app.governance import compute_T, decide_action

SPEC = {}  # normalize_spec par défaut suffit pour ces cas (raw scalaires 0-4)


def test_gate_unknown_when_g_zero():
    csv_norm = {"Q": 1, "D": 1, "K": 1, "X": 1, "E": 1, "S": 1, "M": 1, "G": 0}
    assert compute_confidence_state(csv_norm) == "UNKNOWN"


def test_gate_conflicted_when_d_zero():
    csv_norm = {"Q": 1, "D": 0, "K": 1, "X": 1, "E": 1, "S": 1, "M": 1, "G": 1}
    assert compute_confidence_state(csv_norm) == "CONFLICTED"


def test_gate_degraded_when_fundamental_low():
    csv_norm = {"Q": 0.1, "D": 1, "K": 1, "X": 1, "E": 1, "S": 1, "M": 1, "G": 1}
    assert compute_confidence_state(csv_norm) == "DEGRADED"


def test_gate_fragile():
    csv_norm = {"Q": 1, "D": 1, "K": 1, "X": 1, "E": 0.3, "S": 1, "M": 1, "G": 1}
    assert compute_confidence_state(csv_norm) == "FRAGILE"


def test_gate_robust_requires_all_high():
    csv_norm = {d: 0.8 for d in ["Q", "D", "K", "X", "E", "S", "M", "G"]}
    assert compute_confidence_state(csv_norm) == "ROBUST"


def test_gate_stable_default():
    csv_norm = {"Q": 0.6, "D": 0.6, "K": 0.6, "X": 0.6, "E": 0.6, "S": 0.6, "M": 0.6, "G": 0.6}
    assert compute_confidence_state(csv_norm) == "STABLE"


def test_invariant_c_never_exceeds_cap():
    csv_raw = {d: 4 for d in ["Q", "D", "K", "X", "E", "S", "M", "G"]}
    result = FCSV(csv_raw, SPEC)
    assert result["c"] <= result["c_cap"] + 1e-9


def test_t_independent_of_c():
    """Invariant central : T ne dépend jamais de C (dT/dC = 0)."""
    t1 = compute_T(R=0.9, I=0.9, Rev=0.0)
    t2 = compute_T(R=0.9, I=0.9, Rev=0.0)  # même R,I,Rev, C n'entre jamais en jeu
    assert t1 == t2


def test_maximal_t_forces_escalate_even_with_high_c():
    """Même à C proche de 1.0, T maximal impose une sortie ESCALATE ou STOP,
    jamais ACT — voir Manifeste HIBOU-OS, Partie IX (invariant de prudence).
    State ROBUST (confiance fiable) -> ESCALATE, pas STOP."""
    T = compute_T(R=1.0, I=1.0, Rev=0.0)
    assert T >= 0.9
    assert decide_action(T, C=0.999, confidence_state="ROBUST") == "ESCALATE"


def test_maximal_t_with_broken_confidence_forces_stop():
    """STOP — état de sortie explicite depuis la décision du 21 sept. 2026.
    Critère VALIDÉ le 26 sept. 2026 : State UNKNOWN/CONFLICTED au palier
    maximal -> STOP plutôt qu'ESCALATE (rien de fiable à transmettre)."""
    T = compute_T(R=1.0, I=1.0, Rev=0.0)
    assert T >= 0.9
    assert decide_action(T, C=0.1, confidence_state="UNKNOWN") == "STOP"
    assert decide_action(T, C=0.1, confidence_state="CONFLICTED") == "STOP"


def test_maximal_t_never_returns_act_verify_recommend():
    """Invariant : au palier maximal, seules STOP et ESCALATE sont
    admissibles en sortie — jamais ACT/VERIFY/RECOMMEND."""
    T = compute_T(R=1.0, I=1.0, Rev=0.0)
    for state in ["UNKNOWN", "CONFLICTED", "DEGRADED", "FRAGILE", "STABLE", "ROBUST"]:
        assert decide_action(T, C=0.9, confidence_state=state) in ("STOP", "ESCALATE")


def test_high_t_band_c_still_matters():
    """Régression pour le bug corrigé : dans la bande T élevé, C doit
    changer le résultat (ACT vs RECOMMEND), pas rester figé sur RECOMMEND."""
    T = 0.75  # bande "eleve" : 0.7 <= T < 0.9
    assert decide_action(T, C=0.9) == "ACT"
    assert decide_action(T, C=0.5) == "RECOMMEND"
