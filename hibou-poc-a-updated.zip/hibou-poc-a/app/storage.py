# storage.py
# SCI-MEM minimal — trace chaque décision (DecisionRecord) et son
# éventuel résultat observé (Partie 7 du Document Technique v0 :
# feedback à 3 canaux, jamais de réapprentissage en temps réel).

import json
import os
import sqlite3
import uuid
from datetime import datetime

DB_PATH = os.environ.get("HIBOU_DB", "hibou_poc.db")


class DecisionStore:
    def __init__(self, db_path=None):
        self.conn = sqlite3.connect(db_path or DB_PATH, check_same_thread=False)
        self._init_schema()

    def _init_schema(self):
        c = self.conn.cursor()
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS decisions (
                id TEXT PRIMARY KEY,
                timestamp TEXT,
                context TEXT,
                confidence_report TEXT,
                R REAL, I REAL, Rev REAL, T REAL,
                action TEXT,
                verdict_status TEXT DEFAULT 'EN_ATTENTE',
                outcome TEXT,
                outcome_metrics TEXT,
                outcome_horizon TEXT,
                outcome_notes TEXT,
                outcome_timestamp TEXT
            )
            """
        )
        self.conn.commit()

    def save_decision(self, context, conf, R, I, Rev, T, action):
        decision_id = str(uuid.uuid4())
        ts = datetime.utcnow().isoformat() + "Z"
        c = self.conn.cursor()
        c.execute(
            "INSERT INTO decisions (id, timestamp, context, confidence_report, R, I, Rev, T, action, verdict_status) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'EN_ATTENTE')",
            (decision_id, ts, json.dumps(context), json.dumps(conf), R, I, Rev, T, action),
        )
        self.conn.commit()
        return decision_id

    def save_outcome(self, decision_id, outcome, metrics=None, horizon="IMMEDIAT", notes=None):
        """Relie un résultat observé à une décision tracée (canal de vérité
        terrain — voir Document Technique v0, Partie 7). N'ajuste jamais
        les poids/seuils en direct ; alimente seulement la traçabilité
        pour un cycle de recalibration gouverné ultérieur."""
        ts = datetime.utcnow().isoformat() + "Z"
        c = self.conn.cursor()
        c.execute(
            "UPDATE decisions SET verdict_status = 'OBSERVE', outcome = ?, outcome_metrics = ?, "
            "outcome_horizon = ?, outcome_notes = ?, outcome_timestamp = ? WHERE id = ?",
            (outcome, json.dumps(metrics or {}), horizon, notes, ts, decision_id),
        )
        self.conn.commit()
        return c.rowcount > 0

    def get_decision(self, decision_id):
        c = self.conn.cursor()
        c.execute(
            "SELECT id, timestamp, context, confidence_report, R, I, Rev, T, action, "
            "verdict_status, outcome, outcome_metrics, outcome_horizon, outcome_notes, outcome_timestamp "
            "FROM decisions WHERE id = ?",
            (decision_id,),
        )
        row = c.fetchone()
        if row is None:
            return None
        keys = ["id", "timestamp", "context", "confidence_report", "R", "I", "Rev", "T", "action",
                "verdict_status", "outcome", "outcome_metrics", "outcome_horizon", "outcome_notes", "outcome_timestamp"]
        record = dict(zip(keys, row))
        record["context"] = json.loads(record["context"])
        record["confidence_report"] = json.loads(record["confidence_report"])
        if record["outcome_metrics"]:
            record["outcome_metrics"] = json.loads(record["outcome_metrics"])
        return record

    def all_decisions(self):
        c = self.conn.cursor()
        c.execute("SELECT id, timestamp, context, confidence_report, R, I, Rev, T, action FROM decisions")
        return c.fetchall()

