# app.py — Façade Kernel minimale.
# Point d'entrée unique : voir Document Technique v0, Partie 2
# (submit_decision_context — le seul contrat exposé aux applications).

import os

import yaml
from flask import Flask, jsonify, request

from .compute_confidence import FCSV
from .governance import compute_T, decide_action
from .storage import DecisionStore

app = Flask(__name__)

_spec_path = os.path.join(os.path.dirname(__file__), "normalize_spec.yaml")
with open(_spec_path, "r") as f:
    NORMALIZE_SPEC = yaml.safe_load(f)

store = DecisionStore()


@app.route("/compute_confidence", methods=["POST"])
def compute_confidence():
    payload = request.get_json(force=True)
    csv_raw = payload.get("csv_raw", {})
    result = FCSV(csv_raw, NORMALIZE_SPEC)
    return jsonify(result)


@app.route("/submit_decision_context", methods=["POST"])
def submit_decision_context():
    payload = request.get_json(force=True)
    context = payload.get("context", {})
    R = float(payload.get("R", 0.0))
    I = float(payload.get("I", 0.0))
    Rev = float(payload.get("Rev", 1.0))
    csv_raw = payload.get("csv_raw", {})

    conf = FCSV(csv_raw, NORMALIZE_SPEC)
    T = compute_T(R, I, Rev)
    C = conf["c"]
    A = decide_action(T, C, confidence_state=conf["state"])

    decision_id = store.save_decision(context, conf, R, I, Rev, T, A)

    return jsonify({
        "A": A,
        "C": C,
        "State": conf["state"],
        "T": T,
        "confidence_report": conf,
        "decision_id": decision_id,
    })


@app.route("/outcome", methods=["POST"])
def outcome():
    """Relie un résultat observé à une décision tracée — un des 3 canaux
    de vérité terrain (Document Technique v0, Partie 7). N'ajuste jamais
    T ou les hard gates en direct : alimente seulement SCI-MEM pour un
    cycle de recalibration gouverné, périodique et audité."""
    payload = request.get_json(force=True)
    decision_id = payload.get("decision_id")
    outcome_value = payload.get("outcome")  # SUCCESS | FAIL | PARTIAL
    metrics = payload.get("metrics", {})
    horizon = payload.get("horizon", "IMMEDIAT")  # IMMEDIAT | COURT_DELAI | LONG_DELAI
    notes = payload.get("notes")

    if not decision_id or not outcome_value:
        return jsonify({"error": "decision_id et outcome sont requis"}), 400

    updated = store.save_outcome(decision_id, outcome_value, metrics, horizon, notes)
    if not updated:
        return jsonify({"error": "decision_id introuvable"}), 404

    return jsonify({"decision_id": decision_id, "verdict_status": "OBSERVE", "acknowledged": True})


@app.route("/decision/<decision_id>", methods=["GET"])
def get_decision(decision_id):
    """Récupère le DecisionRecord complet — traçabilité et audit."""
    record = store.get_decision(decision_id)
    if record is None:
        return jsonify({"error": "decision_id introuvable"}), 404
    return jsonify(record)


@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080)
