# governance.py
# Confidence Governance Engine — version POC.
# T = f(R, I, Rev), indépendant de C (invariant dT/dC = 0).
# A = h(T, C) — brouillon de travail, voir Document Technique v0, Partie 5.
# Statut : hypothèse de travail, non calibré.

from .config import (
    T_WEIGHTS, T_BINS, C_ACT_THRESHOLD_LOW_T, C_ACT_THRESHOLD_MID_T,
    C_ACT_THRESHOLD_HIGH_T, STOP_CONFIDENCE_STATES,
)


def compute_T(R, I, Rev):
    """Première forme concrète de T = f(R, I, Rev). Ne dépend jamais de C."""
    t = (
        T_WEIGHTS["R"] * R
        + T_WEIGHTS["I"] * I
        + T_WEIGHTS["REV_COMPLEMENT"] * (1 - Rev)
    )
    return min(1.0, max(0.0, t))


def decide_action(T, C, confidence_state=None):
    """A = h(T, C). C influence toujours le comportement, sauf au palier
    maximal où le système sort inconditionnellement du flux normal (voir
    Manifeste HIBOU-OS, Partie IX : l'invariant de prudence).

    Au palier maximal, la sortie est STOP ou ESCALATE (jamais ACT/RECOMMEND/
    VERIFY) — STOP est un état de sortie explicite depuis la décision du
    21 sept. 2026 (Partie VII.7), distinct d'ESCALATE. Critère VALIDÉ le
    26 sept. 2026 : STOP si le State de confiance lui-même est
    UNKNOWN/CONFLICTED (rien de fiable à transmettre à un humain), sinon
    ESCALATE (contexte disponible, transmis pour arbitrage humain). Voir
    STOP_CONFIDENCE_STATES dans config.py."""
    if T >= T_BINS["maximal"]:
        if confidence_state in STOP_CONFIDENCE_STATES:
            return "STOP"
        return "ESCALATE"

    if T >= T_BINS["eleve"]:
        return "ACT" if C >= C_ACT_THRESHOLD_HIGH_T else "RECOMMEND"

    if T >= T_BINS["modere"]:
        return "ACT" if C >= C_ACT_THRESHOLD_MID_T else "VERIFY"

    return "ACT" if C >= C_ACT_THRESHOLD_LOW_T else "VERIFY"
