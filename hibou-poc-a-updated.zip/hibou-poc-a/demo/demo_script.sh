#!/usr/bin/env bash
set -e

echo "1. Démarrage du service..."
export FLASK_APP=app/app.py
flask run --host=0.0.0.0 --port=8080 &
SERVER_PID=$!
sleep 2

echo "2. Scénario — paiement irréversible (T maximal -> ESCALATE malgré C élevé) :"
curl -s -X POST http://localhost:8080/submit_decision_context \
  -H "Content-Type: application/json" \
  -d '{
    "context": {"scenario": "paiement_irreversible"},
    "R": 0.95, "I": 1.0, "Rev": 0.0,
    "csv_raw": {"Q": 4, "D": 4, "K": 4, "X": 4, "E": 4, "S": 4, "M": 4, "G": 4}
  }' | python3 -m json.tool

echo "3. Scénario — contradiction de sources (D=0 -> CONFLICTED, C plafonné) :"
curl -s -X POST http://localhost:8080/compute_confidence \
  -H "Content-Type: application/json" \
  -d '{"csv_raw": {"Q": 3, "D": 0, "K": 3, "X": 3, "E": 3, "S": 3, "M": 3, "G": 3}}' \
  | python3 -m json.tool

kill $SERVER_PID
