# HIBOU POC A — SCI-META minimal + Kernel façade

Démontre le pipeline CSV → State → C et l'invariant constitutionnel
`C ≤ Cap(State)`, ainsi qu'une première version concrète (non calibrée)
de `T = f(R, I, Rev)` et de l'automate `A = h(T, C)`.

**Statut : hypothèse de travail.** Les poids (`ALPHA_WEIGHTS`), les seuils
(`THRESHOLDS`), les plafonds (`STATE_CAP`) et la formule de `T` sont des
ancrages initiaux — voir `app/config.py`. Rien ici n'est calibré
empiriquement ; ce dépôt sert à prouver que le mécanisme fonctionne, pas
qu'il est juste.

## Quickstart (local)

```bash
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
export FLASK_APP=app/app.py
flask run --host=0.0.0.0 --port=8080
```

## Endpoints

- `POST /compute_confidence` → `{ "csv_raw": {...} }`
- `POST /submit_decision_context` → `{ "context": {...}, "R": 0-1, "I": 0-1, "Rev": 0-1, "csv_raw": {...} }`
- `POST /outcome` → `{ "decision_id": "...", "outcome": "SUCCESS|FAIL|PARTIAL", "metrics": {...}, "horizon": "IMMEDIAT|COURT_DELAI|LONG_DELAI" }` — un des 3 canaux de vérité terrain (Document Technique v0, Partie 7) ; met à jour `verdict_status` sans jamais ajuster T ou les hard gates en direct
- `GET /decision/{decision_id}` → DecisionRecord complet, y compris l'outcome s'il a été rapporté

## Générer un dataset synthétique de test

```bash
python3 scripts/generate_dataset.py --mode C1 --mode C2 --mode C3 --n 300
```

Trois profils : C1 (équilibré par Confidence State, pour vérifier la
couverture logique des hard gates), C2 (distribution réaliste), C3
(adverse — bruit et anomalies volontaires pour stress-tester le pipeline).

**Ce jeu synthétique sert à tester la cohérence du mécanisme, pas à le
calibrer.** La calibration réelle (Document Technique v0, Partie 10)
repose sur quelques centaines de décisions réelles tracées via SCI-MEM,
pas sur des données générées.

## Dashboard de démonstration

```bash
flask run --host=0.0.0.0 --port=8080 &
streamlit run demo/dashboard.py
```

Visualise la distribution des Confidence States, l'effet du plafonnement
(C_raw vs C), un inspecteur de décision, et vérifie l'invariant
`C ≤ Cap(State)` sur l'ensemble du dataset chargé.

## Tests

```bash
pytest app/tests -v
```

## Démo rapide

```bash
bash demo/demo_script.sh
```

## Livrables inclus

- Microservice SCI-META (`compute_confidence.py`)
- Façade Kernel minimale (`app.py`)
- Traçabilité SCI-MEM (`storage.py`, SQLite par défaut — voir `HIBOU_DB` dans l'environnement pour changer de fichier)
- 2 décisions d'exemple (`app/sample_data/decisions_sample.json`) — à étoffer vers quelques dizaines pour un premier test de cohérence (voir le Document Technique v0, Partie 10 : pas besoin de 500 dès ce stade)
- Tests unitaires pour les hard gates et les endpoints

## Ce qui a été corrigé par rapport à la version reçue

1. Identifiants corrompus lors d'un transfert précédent (`csvraw` → `csv_raw`,
   `computeconfidencestate` → `compute_confidence_state`, etc.) et opérateurs
   de multiplication manquants dans `normalize_value`.
2. Bug dans `h(T, C)` : la bande `T ∈ [0.7, 0.9)` retournait `RECOMMEND`
   quelle que soit la valeur de `C`. Corrigé pour que `C` influence toujours
   le comportement, sauf au palier maximal où `ESCALATE` est inconditionnel
   par construction (voir Manifeste HIBOU-OS, Partie IX).
3. `dashboard.py` reçu séparément était corrompu plus sévèrement (guillemets
   français `« »` à la place des guillemets Python, mots-clés capitalisés,
   `results.append®` au lieu de `results.append(r)`) — réécrit entièrement
   dans `demo/dashboard.py`, aligné sur les noms de champs réels du service
   (`csv_raw`, `c_raw`, `c`, `c_cap`, `state`).

## Mise à jour du 26 sept. 2026 — STOP comme état de sortie explicite

Décision validée par Denard (Manifeste HIBOU-OS, Partie VII.7) : `STOP` doit
être un état de sortie explicite de `A = h(T, C)`, au même titre
qu'`ACT`/`VERIFY`/`RECOMMEND`/`ESCALATE` — il n'existait auparavant que
parmi les 5 états de la Metacognition (`STOP/SEEK/VERIFY/ESCALATE/ACT`),
pas dans l'automate.

**Ce qui a changé** :
- `decide_action(T, C)` devient `decide_action(T, C, confidence_state)`.
- Au palier maximal (`T ≥ 0.9`), la sortie est maintenant `STOP` **ou**
  `ESCALATE` — jamais `ACT`/`VERIFY`/`RECOMMEND` — au lieu d'`ESCALATE`
  inconditionnel.

**Critère STOP vs ESCALATE — VALIDÉ le 26 sept. 2026** (tranché par Denard,
à confirmer avec Roqia lors de la calibration empirique) : si le
Confidence State lui-même est `UNKNOWN` ou `CONFLICTED` (hard gate `G=0`
ou `D=0`), la pipeline de confiance a échoué — rien de fiable à
transmettre à un humain → `STOP` (arrêt immédiat, fail-safe autonome).
Si le State est connu, même dégradé → `ESCALATE` (transmission de
contexte pour arbitrage humain). Voir `STOP_CONFIDENCE_STATES` dans
`config.py`.

3 tests ajoutés dans `test_compute_confidence.py` couvrent ce comportement
et l'invariant "jamais ACT/VERIFY/RECOMMEND au palier maximal".
